import tensorflow as tf
from tensorflow.keras.layers import Embedding, LSTM, Dense
from tensorflow.keras.models import Sequential
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.preprocessing.sequence import pad_sequences

# Подготовка данных для обучения (здесь используется пример)
train_data = [
    "Привет, как дела?",
    "Что нового?",
    "Как я могу вам помочь?",
    "Пока, до свидания!"
]

# Создание токенизатора и преобразование текстовых данных в последовательности чисел
tokenizer = Tokenizer()
tokenizer.fit_on_texts(train_data)
total_words = len(tokenizer.word_index) + 1  # Общее количество уникальных слов

input_sequences = []
for line in train_data:
    token_list = tokenizer.texts_to_sequences([line])[0]
    for i in range(1, len(token_list)):
        n_gram_sequence = token_list[:i+1]
        input_sequences.append(n_gram_sequence)

# Создание входных и выходных данных для модели
max_sequence_length = max([len(x) for x in input_sequences])
input_sequences = pad_sequences(input_sequences, maxlen=max_sequence_length, padding='pre')
X = input_sequences[:, :-1]
y = input_sequences[:, -1]

# Создание и компиляция модели
model = Sequential()
model.add(Embedding(total_words, 64, input_length=max_sequence_length-1))
model.add(LSTM(100))
model.add(Dense(total_words, activation='softmax'))
model.compile(loss='sparse_categorical_crossentropy', optimizer='adam', metrics=['accuracy'])

# Обучение модели
model.fit(X, y, epochs=100, verbose=1)

# Сохранение модели в файл
# Пример с указанием формата сохранения как "tf"
model.save("my_chatbot_model", save_format="tf")

